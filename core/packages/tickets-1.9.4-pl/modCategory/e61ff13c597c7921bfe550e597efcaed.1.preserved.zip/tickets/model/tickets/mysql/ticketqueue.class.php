<?php
require_once (dirname(__DIR__) . '/ticketqueue.class.php');
class TicketQueue_mysql extends TicketQueue {}