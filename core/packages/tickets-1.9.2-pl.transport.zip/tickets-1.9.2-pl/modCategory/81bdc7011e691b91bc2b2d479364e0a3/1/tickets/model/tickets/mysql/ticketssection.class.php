<?php
require_once (dirname(__DIR__) . '/ticketssection.class.php');
class TicketsSection_mysql extends TicketsSection {}