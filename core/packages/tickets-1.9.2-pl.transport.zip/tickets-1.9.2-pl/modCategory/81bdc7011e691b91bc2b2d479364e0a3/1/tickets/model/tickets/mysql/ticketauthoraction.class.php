<?php
require_once (dirname(__DIR__) . '/ticketauthoraction.class.php');
class TicketAuthorAction_mysql extends TicketAuthorAction {}