<?php
require_once (dirname(__DIR__) . '/ticketthread.class.php');
class TicketThread_mysql extends TicketThread {}